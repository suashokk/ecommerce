package com.example.saas.service;

import com.example.saas.model.CustomerData;
import com.github.javafaker.Faker;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class DataGeneratorService {

    private final Faker faker = new Faker();

    public List<CustomerData> generateData(int count) {
        List<CustomerData> dataList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            CustomerData data = new CustomerData();
            data.setId(UUID.randomUUID().toString());
            data.setName(faker.name().fullName());
            data.setEmail(faker.internet().emailAddress());
            data.setPhone(faker.phoneNumber().cellPhone());
            data.setAddress(faker.address().fullAddress());
            dataList.add(data);
        }
        return dataList;
    }
}
