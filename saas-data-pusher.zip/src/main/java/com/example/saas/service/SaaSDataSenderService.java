package com.example.saas.service;

import com.example.saas.model.CustomerData;
import io.github.resilience4j.retry.Retry;
import io.github.resilience4j.retry.RetryConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.time.Duration;
import java.util.List;

@Service
@Slf4j
public class SaaSDataSenderService {

    private final WebClient webClient;
    private static final String SAAS_API_URL = "https://your-saas-api.com/data";

    private final Retry retry;

    public SaaSDataSenderService(WebClient webClient) {
        this.webClient = webClient;

        this.retry = Retry.of("saas-retry", RetryConfig.custom()
                .maxAttempts(3)
                .waitDuration(Duration.ofSeconds(2))
                .build());
    }

    public void sendData(List<CustomerData> dataBatch) {
        log.info("Sending {} records to SaaS system...", dataBatch.size());

        retry.executeRunnable(() -> {
            webClient.post()
                    .uri(SAAS_API_URL)
                    .bodyValue(dataBatch)
                    .retrieve()
                    .bodyToMono(String.class)
                    .doOnSuccess(response -> log.info("Successfully sent batch"))
                    .doOnError(error -> log.error("Failed to send batch: {}", error.getMessage()))
                    .block();
        });
    }
}
