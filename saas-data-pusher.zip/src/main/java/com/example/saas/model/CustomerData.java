package com.example.saas.model;

import lombok.Data;

@Data
public class CustomerData {
    private String id;
    private String name;
    private String email;
    private String phone;
    private String address;
}
