package com.example.saas;

import com.example.saas.model.CustomerData;
import com.example.saas.service.DataGeneratorService;
import com.example.saas.service.SaaSDataSenderService;
import com.example.saas.util.RateLimiter;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.List;

@SpringBootApplication
public class SaaSDataPusherApplication implements CommandLineRunner {

    private final DataGeneratorService dataGeneratorService;
    private final SaaSDataSenderService saasDataSenderService;
    private final RateLimiter rateLimiter = new RateLimiter(5);

    public SaaSDataPusherApplication(DataGeneratorService dataGeneratorService,
                                     SaaSDataSenderService saasDataSenderService) {
        this.dataGeneratorService = dataGeneratorService;
        this.saasDataSenderService = saasDataSenderService;
    }

    public static void main(String[] args) {
        SpringApplication.run(SaaSDataPusherApplication.class, args);
    }

    @Override
    public void run(String... args) {
        int totalRecords = 5_000_000;
        int batchSize = 10_000;

        for (int i = 0; i < totalRecords; i += batchSize) {
            List<CustomerData> batch = dataGeneratorService.generateData(batchSize);
            rateLimiter.acquire();
            saasDataSenderService.sendData(batch);
            rateLimiter.release();
        }
    }
}
