package com.example.saas.util;

import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

public class RateLimiter {
    private final Semaphore semaphore;

    public RateLimiter(int maxRequestsPerSecond) {
        this.semaphore = new Semaphore(maxRequestsPerSecond);
    }

    public void acquire() {
        try {
            if (!semaphore.tryAcquire(1, TimeUnit.SECONDS)) {
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void release() {
        semaphore.release();
    }
}
