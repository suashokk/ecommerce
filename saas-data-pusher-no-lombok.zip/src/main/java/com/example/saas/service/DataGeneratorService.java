package com.example.saas.service;

import com.example.saas.model.CustomerData;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class DataGeneratorService {

    public List<CustomerData> generateData(int count) {
        List<CustomerData> dataList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            dataList.add(new CustomerData(
                UUID.randomUUID().toString(),
                "Customer " + i,
                "customer" + i + "@example.com",
                "+91-987654321" + (i % 10),
                "Address " + i
            ));
        }
        return dataList;
    }
}
