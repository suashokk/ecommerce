package com.example.saas.service;

import com.example.saas.model.CustomerData;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.List;

@Service
public class SaaSDataSenderService {

    private static final Logger log = LoggerFactory.getLogger(SaaSDataSenderService.class);
    private final WebClient webClient;
    private static final String SAAS_API_URL = "https://your-saas-api.com/data"; // Replace with actual API

    public SaaSDataSenderService(WebClient webClient) {
        this.webClient = webClient;
    }

    public void sendData(List<CustomerData> dataBatch) {
        log.info("Sending {} records to SaaS system...", dataBatch.size());

        try {
            webClient.post()
                    .uri(SAAS_API_URL)
                    .bodyValue(dataBatch)
                    .retrieve()
                    .bodyToMono(String.class)
                    .doOnSuccess(response -> log.info("Successfully sent batch"))
                    .doOnError(error -> log.error("Failed to send batch: {}", error.getMessage()))
                    .block();
        } catch (Exception e) {
            log.error("Error sending data: {}", e.getMessage());
        }
    }
}
