package com.example.filetransfer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileTransferServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(FileTransferServiceApplication.class, args);
    }
}
