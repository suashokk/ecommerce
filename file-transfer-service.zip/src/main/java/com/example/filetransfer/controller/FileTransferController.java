package com.example.filetransfer.controller;

import lombok.extern.slf4j.Slf4j;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.io.entity.MultipartEntityBuilder;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@RestController
@RequestMapping("/file")
@Slf4j
public class FileTransferController {

    private final String TARGET_SERVICE_URL = "http://another-network.com/upload"; // Change to actual destination URL

    @PostMapping("/send")
    public ResponseEntity<String> sendFile(@RequestParam("file") MultipartFile file) {
        File tempFile = null;
        try {
            tempFile = convertMultipartFileToFile(file);
            boolean isSent = sendFileToAnotherNetwork(tempFile);
            tempFile.delete();
            return isSent ? ResponseEntity.ok("File sent successfully!") :
                    ResponseEntity.status(HttpStatus.BAD_GATEWAY).body("File sending failed!");
        } catch (IOException e) {
            log.error("File processing error: ", e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("File processing error!");
        }
    }

    private boolean sendFileToAnotherNetwork(File file) {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost postRequest = new HttpPost(TARGET_SERVICE_URL);
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.addBinaryBody("file", file);
            postRequest.setEntity(builder.build());

            try (CloseableHttpResponse response = httpClient.execute(postRequest)) {
                return response.getCode() == 200;
            }
        } catch (Exception e) {
            log.error("Error sending file: ", e);
            return false;
        }
    }

    private File convertMultipartFileToFile(MultipartFile multipartFile) throws IOException {
        File convFile = File.createTempFile("upload-", "-" + multipartFile.getOriginalFilename());
        try (FileOutputStream fos = new FileOutputStream(convFile)) {
            fos.write(multipartFile.getBytes());
        }
        return convFile;
    }
}
